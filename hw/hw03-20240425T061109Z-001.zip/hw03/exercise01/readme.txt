When you're done with the first 14 steps of CSS Diner, save your screenshot in this folder.'Courier New'.
