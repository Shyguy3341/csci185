function changeBackground() {
    // your code here
}

function goodbye() {
    // your code here
}

function showDog() {
    // your code here
}
